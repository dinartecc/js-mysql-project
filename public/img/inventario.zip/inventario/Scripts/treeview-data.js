$(document).ready(function () {
var data = [{"text":"Cover Page","icon":"images/folder.svg","href":"startpage.html","target":"DATA"},{"text":"Servers","icon":"images/folder.svg","href":"Servers\\Servers.html","target":"DATA"},{"text":"inventario.localhost:8070","icon":"images/folder.svg","href":"Servers\\inventario.localhost_8070\\inventario.localhost_8070.html","target":"DATA","nodes":[{"text":"Databases","icon":"images/folder.svg","href":"Servers\\inventario.localhost_8070\\Databases\\Databases.html","target":"DATA","nodes":[{"text":"inventario","icon":"images/database.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\inventario.html","target":"DATA","nodes":[{"text":"Tables","icon":"images/folder.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\Tables.html","target":"DATA","nodes":[{"text":"almacen","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\almacen.html","target":"DATA"},{"text":"categoria","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\categoria.html","target":"DATA"},{"text":"cliente","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\cliente.html","target":"DATA"},{"text":"lotes","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\lotes.html","target":"DATA"},{"text":"marca","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\marca.html","target":"DATA"},{"text":"producto","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\producto.html","target":"DATA"},{"text":"proveedor","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\proveedor.html","target":"DATA"},{"text":"roles","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\roles.html","target":"DATA"},{"text":"sessions","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\sessions.html","target":"DATA"},{"text":"subcategoria","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\subcategoria.html","target":"DATA"},{"text":"usuarios","icon":"images/table.svg","href":"Servers\\inventario.localhost_8070\\Databases\\inventario\\Tables\\usuarios.html","target":"DATA"}]}]}]}]}];
$('#tree').treeview({levels: 3,data: data,enableLinks: true,injectStyle: false,highlightSelected: true,collapseIcon: 'images/tree-node-expanded.svg',expandIcon: 'images/tree-node-collapsed.svg'});
});
var loadEvent = function () {

  $('#btn-expand-nodes').on('click', function (e) {
    $('#tree').treeview('expandAll', { silent: true });
  });
  $('#btn-collapse-nodes').on('click', function (e) {
    $('#tree').treeview('collapseAll', { levels:3, silent: true });
  });
  
  var searchTimeOut;
  $('#input-search').on('input', function() {
    if(searchTimeOut != null)
      clearTimeout(searchTimeOut);
    searchTimeOut = setTimeout(function(){
      var pattern = $('#input-search').val();
      var tree = $('#tree');
      tree.treeview('collapseAll', { levels:3, silent: true });
      var options = { ignoreCase: true, exactMatch: false, revealResults: true };
      var results = tree.treeview('search', [pattern, options]);
    }, 500);
  });
  
  $('#tree').on('nodeSelected', function(event, data) {
    // navigate to link
    window.open (data.href, 'DATA', false)
  });
  // select first node.
  $('#tree').treeview('selectNode', [0, { silent: false }]);
}

if (window.addEventListener) {
  window.addEventListener('load', loadEvent, false);
}
else if (window.attachEvent) {
  window.attachEvent('onload', loadEvent);
}